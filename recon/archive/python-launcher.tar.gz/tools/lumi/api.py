"""Lumin launcher 的签名 API 客户端（绿梦：时空之声 / zhuziplay）。

签名方案完全复刻自 starter SPA 的 addSignatureHeaders：
  secret   = SIGNATURE_SECRET
  headers  = x_app_id / x_device_id / x_nonce / x_platform / x_timestamp
  payload  = pct(method.upper()) + pct(path) + "&"
             + "&".join(f"{k}={v}" for k in sorted(headers)) + "&key=" + secret
  x_signature = base64(nonce12 + AESGCM(sha256(secret + "_aes"), nonce12, hex(HMAC_SHA256(secret, payload)))

注意 method 与 path 之间没有分隔符，pct 是 encodeURIComponent + [!'()*] 转义。
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import random
import string
import time
import urllib.error
import urllib.parse
import urllib.request

API_BASE = "https://lmapi.zhuziplay.com"
STARTER_BASE = "https://lvmeng-starter.zhuziplay.com"
SIGNATURE_SECRET = "57e5177a6752ef98e3a7c9b6c9f06e35"
SIGNATURE_PLATFORM = "Web"
SIGNATURE_APP_ID = "1038"
_NONCE_CHARS = string.ascii_letters + string.digits


class ApiError(RuntimeError):
    def __init__(self, path: str, code, message):
        super().__init__(f"{path} -> code={code} message={message}")
        self.path = path
        self.code = code
        self.message = message


def percent_encode(value: str) -> str:
    out = urllib.parse.quote(value, safe="-_.!~*'()")
    return "".join(f"%{ord(ch):02X}" if ch in "!'()*" else ch for ch in out)


def create_nonce(length: int = 32) -> str:
    rng = random.SystemRandom()
    return "".join(rng.choice(_NONCE_CHARS) for _ in range(length))


def _aes_gcm_encrypt(key: bytes, nonce: bytes, plaintext: bytes) -> bytes:
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        return AESGCM(key).encrypt(nonce, plaintext, None)
    except ImportError:
        from Crypto.Cipher import AES

        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(plaintext)
        return ciphertext + tag


def build_payload(headers: dict[str, str], method: str, path: str) -> str:
    body = f"{percent_encode(method.upper())}{percent_encode(path)}&"
    for key in sorted(headers):
        body += f"{key}={headers[key] if headers[key] is not None else ''}&"
    return f"{body}key={SIGNATURE_SECRET}"


def signature_headers(method: str, path: str, device_id: str) -> dict[str, str]:
    headers = {
        "x_app_id": SIGNATURE_APP_ID,
        "x_device_id": device_id,
        "x_nonce": create_nonce(),
        "x_platform": SIGNATURE_PLATFORM,
        "x_timestamp": str(int(time.time())),
    }
    digest = hmac.new(
        SIGNATURE_SECRET.encode(), build_payload(headers, method, path).encode(), hashlib.sha256
    ).hexdigest()
    key = hashlib.sha256(f"{SIGNATURE_SECRET}_aes".encode()).digest()
    nonce = os.urandom(12)
    sealed = _aes_gcm_encrypt(key, nonce, digest.encode())
    headers["x_signature"] = base64.b64encode(nonce + sealed).decode()
    return headers


class LuminApi:
    """POST-only JSON API。所有接口的 body 都必须带 region/launcher_env/channel/device_id。"""

    def __init__(
        self,
        device_id: str,
        region: str = "CN",
        launcher_env: str = "Prod",
        channel: str = "bilibili",
        cps: str = "",
        token: str | None = None,
        base_url: str = API_BASE,
        timeout: float = 30.0,
    ) -> None:
        self.device_id = device_id
        self.region = region
        self.launcher_env = launcher_env
        self.channel = channel
        self.cps = cps
        self.token = token
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def post(self, path: str, payload: dict | None = None) -> object:
        body = dict(payload or {})
        body.setdefault("region", self.region)
        body.setdefault("launcher_env", self.launcher_env)
        body.setdefault("channel", self.channel)
        body.setdefault("device_id", self.device_id)
        raw = json.dumps(body, ensure_ascii=False).encode()
        headers = {
            "Content-Type": "application/json;charset=UTF-8",
            "Accept": "application/json, text/plain, */*",
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
            ),
            "Origin": STARTER_BASE,
            "Referer": STARTER_BASE + "/",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        headers.update(signature_headers("POST", path, self.device_id))
        req = urllib.request.Request(self.base_url + path, data=raw, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                envelope = json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:  # 401/403/500 保留原始报文
            raise ApiError(path, exc.code, exc.read().decode(errors="replace")[:500]) from exc
        if envelope.get("code") != 0:
            raise ApiError(path, envelope.get("code"), envelope.get("message"))
        return envelope.get("data")

    # /launcher/app：下载地址 + 版本 + update 段
    def launcher_app(self, **extra) -> dict:
        return self.post("/launcher/app", extra) or {}

    def launcher_update(self, client_version: str) -> dict | None:
        return self.post("/launcher/update", {"client_version": client_version})

    def native_build_id(self, **extra) -> dict:
        return self.post("/native/buildId", extra) or {}

    def remote_config(self, **extra) -> dict:
        return self.post("/remote/config", extra) or {}

    def announcement(self, **extra) -> dict:
        return self.post("/launcher/announcement", extra) or {}

    def banner(self, **extra) -> dict:
        return self.post("/launcher/banner", extra) or {}

    def shield(self, **extra) -> dict:
        return self.post("/launcher/shield", extra) or {}
