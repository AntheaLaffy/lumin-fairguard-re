"""断点续传下载器：与 LuminDownloader / LuminResourceDownloader 行为对齐。

- HTTP Range 续传；服务端忽略 Range 时回退重下
- 校验：长度必须与 Content-Length 一致；资源 zip 额外做 CRC 全量校验
- 失败重试 3 次，速度超限时可暂停
"""

from __future__ import annotations

import os
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

CHUNK = 1 << 20


class DownloadError(RuntimeError):
    pass


def _remote_size(url: str, timeout: float = 30.0) -> int:
    req = urllib.request.Request(url, method="HEAD")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        size = int(resp.headers.get("Content-Length") or 0)
    if size <= 0:
        raise DownloadError(f"远端未返回有效 Content-Length: {url}")
    return size


def _fmt(size: float) -> str:
    for unit in ("B", "K", "M", "G", "T"):
        if size < 1024 or unit == "T":
            return f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}T"


def download(
    url: str,
    dest: Path,
    expected_size: int = 0,
    total_hint: str = "",
    speed_limit_mb: int = 0,
    retries: int = 3,
    quiet: bool = False,
) -> Path:
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    size = expected_size or _remote_size(url)
    for attempt in range(1, retries + 2):
        try:
            _download_once(url, dest, size, speed_limit_mb, total_hint, quiet)
            break
        except (DownloadError, urllib.error.URLError, TimeoutError, OSError) as exc:
            if attempt > retries:
                raise DownloadError(f"下载失败（{attempt - 1} 次重试后）{url}: {exc}") from exc
            if not quiet:
                print(f"  ! 中断：{exc}；{attempt}/{retries} 重试", file=sys.stderr)
            time.sleep(min(2 * attempt, 6))
    if dest.stat().st_size != size:
        raise DownloadError(f"文件长度不符：{dest} {dest.stat().st_size} != {size}")
    return dest


def _download_once(
    url: str, dest: Path, size: int, speed_limit_mb: int, total_hint: str, quiet: bool
) -> None:
    start = dest.stat().st_size if dest.exists() else 0
    if start > size:
        dest.unlink()
        start = 0
    if start == size:
        if not quiet:
            print(f"  已存在完整文件：{dest.name}", file=sys.stderr)
        return
    headers = {"User-Agent": "lumi-linux/1.0"}
    if start:
        headers["Range"] = f"bytes={start}-"
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=60) as resp:
        if start and resp.status == 200:
            start = 0  # 服务端忽略 Range，从头写
            mode = "wb"
        else:
            mode = "ab" if start else "wb"
        written = start
        t0 = time.time()
        last = 0.0
        with open(dest, mode) as fh:
            while True:
                chunk = resp.read(CHUNK)
                if not chunk:
                    break
                fh.write(chunk)
                written += len(chunk)
                now = time.time()
                if not quiet and now - last > 1.0:
                    last = now
                    speed = (written - start) / max(now - t0, 0.001)
                    pct = written / size * 100
                    label = total_hint or dest.name
                    print(
                        f"\r  {label}: {pct:5.1f}%  {_fmt(written)}/{_fmt(size)}  {_fmt(speed)}/s",
                        end="",
                        flush=True,
                        file=sys.stderr,
                    )
                if speed_limit_mb > 0:
                    expected = (written - start) / (speed_limit_mb * 1024 * 1024)
                    drift = expected - (now - t0)
                    if drift > 0.02:
                        time.sleep(min(drift, 0.2))
    if not quiet:
        print(file=sys.stderr)
    if written < size:
        raise DownloadError(f"连接提前结束：{written}/{size}")


def verify_zip(path: Path, expected_size: int = 0) -> bool:
    """对齐 IsDownloadedZipValid：长度 + 全量 CRC 测试。"""
    path = Path(path)
    if not path.exists():
        return False
    if expected_size and path.stat().st_size != expected_size:
        return False
    try:
        with zipfile.ZipFile(path) as zf:
            return zf.testzip() is None
    except (zipfile.BadZipFile, OSError):
        return False


def fetch_json(url: str, timeout: float = 60.0):
    import json

    req = urllib.request.Request(url, headers={"User-Agent": "lumi-linux/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())
