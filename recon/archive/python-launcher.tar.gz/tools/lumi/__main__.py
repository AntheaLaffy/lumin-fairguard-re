"""lumi 命令行入口：python3 -m lumi <command>"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from . import launch as launch_mod
from .api import LuminApi, signature_headers
from .client import KINDS, LumiClient
from .store import GameLayout, LauncherConfig


def _paths(args) -> tuple[Path, Path]:
    data_dir = Path(args.data_dir).expanduser()
    data_dir.mkdir(parents=True, exist_ok=True)
    config = LauncherConfig.ensure_device_id(data_dir)
    if args.game_path:
        config.game_path = str(Path(args.game_path).expanduser())
    if not config.game_path:
        config.game_path = str((Path.home() / "Games" / "lvmeng").resolve())
    config.speed_limit = args.speed_limit or config.speed_limit
    config.save(data_dir)
    return data_dir, Path(config.game_path)


def _client(args) -> tuple[LumiClient, LumiClient, LauncherConfig]:
    data_dir, game_path = _paths(args)
    config = LauncherConfig.load(data_dir)
    layout = GameLayout(game_path)
    api = LuminApi(
        device_id=args.device_id or config.device_id,
        region=args.region,
        launcher_env=args.env,
        channel=args.channel,
        cps=config.cps or args.cps,
        token=args.token,
    )
    return LumiClient(config, layout, api, quiet=args.quiet), config, layout


def cmd_status(args) -> int:
    client, config, layout = _client(args)
    print(json.dumps(client.status(), indent=2, ensure_ascii=False))
    return 0


def cmd_plan(args) -> int:
    client, _, layout = _client(args)
    plan = client.fetch_plan(layout.read_app_info())
    out = {
        "client_version": plan.client_version,
        "client_url": plan.client_url,
        "client_size": plan.client_size,
        "app_env": plan.app_env,
        "server_url": plan.server_url,
        "resource_versions": plan.resource_versions,
        "resources": {
            kind: {"count": len(items), "bytes": sum(i["size"] for i in items)}
            for kind, items in plan.resources.items()
        },
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    if args.verbose:
        for kind, items in plan.resources.items():
            for item in items:
                print(f"{kind:12} {item['size']/1024/1024:9.1f} MiB {item['tag']:<8} {item['url']}")
    return 0


def cmd_install(args) -> int:
    client, _, layout = _client(args)
    plan = client.fetch_plan(layout.read_app_info())
    print(f"远端客户端版本 {plan.client_version}（{plan.client_size/1024/1024:.0f} MiB）")
    client.install_client(plan, force=args.force)
    if args.with_resources:
        kinds = tuple(args.kinds.split(",")) if args.kinds else KINDS
        client.install_resources(plan, kinds=kinds, dry_run=False)
    else:
        print("跳过资源预下载：客户端自己会向同一批 CDN 拉取（实测 22.4 GiB），先玩就先让它下。")
    return 0


def cmd_resources(args) -> int:
    client, _, layout = _client(args)
    plan = client.fetch_plan(layout.read_app_info())
    kinds = tuple(args.kinds.split(",")) if args.kinds else KINDS
    client.install_resources(plan, kinds=kinds, dry_run=args.dry_run)
    return 0


def cmd_repair(args) -> int:
    client, _, _ = _client(args)
    build = args.native_build_id
    if not build:
        info = client.api.native_build_id(
            env=args.env,
            region=args.region,
            client_version=args.client_version,
            channel=args.channel,
        )
        build = info.get("native_build_id")
        sync = info.get("sync_outer_status", 2)
    else:
        sync = args.sync_outer_status
    client.repair(int(build), int(sync))
    return 0


def cmd_launch(args) -> int:
    client, config, layout = _client(args)
    proton_dir = launch_mod.find_proton(args.proton) if args.proton or args.use_proton else None
    prefix = Path(args.prefix).expanduser() if args.prefix else Path(config.extra.get("wine_prefix", "~/.local/share/lumi/prefix")).expanduser()
    return launch_mod.launch(
        layout,
        proton_dir,
        prefix,
        cps=config.cps or args.cps,
        force_d3d11=args.force_d3d11,
        extra_args=args.passthrough,
        dry_run=args.dry_run,
        env_extra=dict(item.split("=", 1) for item in args.set_env or []),
    )


def cmd_sign(args) -> int:
    headers = signature_headers(args.method, args.path, args.device_id or "debug-device")
    print(json.dumps(headers, indent=2))
    return 0


def cmd_unbundle(args) -> int:
    """解析 UnityFS，恢复完整 bundle 或解压数据流。"""
    from .fairguard import FairGuardBundle

    fb = FairGuardBundle(args.bundle)
    info = fb.parse()
    print(json.dumps({
        "signature": info["signature"], "version": info["version"],
        "player": info["player"], "engine": info["engine"],
        "size": info["size"], "flags": hex(info["flags"]),
        "blocks": [{"uSize": u, "cSize": c, "flags": hex(f)} for u, c, f in info["blocks"]],
        "nodes": info["nodes"],
    }, indent=2, ensure_ascii=False))
    if args.snapshot:
        from .fairguard_runtime import FairGuardTransform

        transform = FairGuardTransform(args.snapshot)
        out = args.output or args.bundle + ".decrypted.bundle"
        with open(out, "wb") as fh:
            fh.write(fb.restore(info, transform))
        print(f"已恢复标准 UnityFS -> {out}")
    elif args.keystream:
        ks = bytes.fromhex(args.keystream)
        stream = fb.stream(info, ks)
        out = args.output or args.bundle + ".plain"
        with open(out, "wb") as fh:
            fh.write(stream)
        print(f"已解出数据流 -> {out}（{len(stream)} 字节）")
    else:
        blocks = fb.extract_blocks(info)
        for i, b in enumerate(blocks):
            if b is None:
                print(f"block[{i}]: 无法直接解压（提供 --snapshot 离线恢复）")
    return 0


def cmd_carve(args) -> int:
    """从 CAB 流切割 HybridCLR DLL（自动命名）。"""
    from .fairguard import carve_pe_files

    with open(args.stream, "rb") as fh:
        stream = fh.read()
    outdir = Path(args.output or "carved")
    outdir.mkdir(parents=True, exist_ok=True)
    for item in carve_pe_files(stream):
        safe = item["name"].replace("/", "_").replace("\\", "_")
        path = outdir / f"{item['offset']:08x}_{safe}"
        path.write_bytes(item["data"])
        print(f"{item['offset']:08x} {item['size']:>9}  {item['name']} -> {path.name}")
    return 0


def cmd_dump_meta(args) -> int:
    """从运行中的游戏进程 dump 解密后的 global-metadata.dat（需要 ptrace 权限）。"""
    import importlib.util
    import subprocess
    import sys as _sys

    pid = args.pid or 0
    if not pid:
        out = subprocess.run(["pgrep", "-f", "Bin.Lumin.exe"], capture_output=True, text=True)
        pids = [int(x) for x in out.stdout.split() if x.isdigit()]
        pid = pids[0] if pids else 0
    if not pid:
        print("找不到运行中的 Lumin.exe；用 --pid 指定", file=_sys.stderr)
        return 2
    script = Path(__file__).resolve().parent.parent.parent / "recon" / "dumpmeta_standalone.py"
    if not script.exists():
        print(f"缺少 {script}", file=_sys.stderr)
        return 2
    r = subprocess.run([_sys.executable, str(script), str(pid), args.output], capture_output=True, text=True)
    print(r.stdout, end="")
    if r.stderr:
        print(r.stderr, file=_sys.stderr)
    return r.returncode


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="lumi", description="绿梦/时空之声 Linux 原生启动器")
    ap.add_argument("--data-dir", default=os.environ.get("LUMI_DATA_DIR", "~/.local/share/lumi"))
    ap.add_argument("--game-path", default=os.environ.get("LUMI_GAME_PATH"))
    ap.add_argument("--device-id", default=os.environ.get("LUMI_DEVICE_ID"))
    ap.add_argument("--token", default=os.environ.get("LUMI_TOKEN"))
    ap.add_argument("--channel", default="bilibili")
    ap.add_argument("--region", default="CN")
    ap.add_argument("--env", default="Prod")
    ap.add_argument("--cps", default="")
    ap.add_argument("--speed-limit", type=int, default=0, help="MiB/s，0 表示不限速")
    ap.add_argument("--quiet", action="store_true")
    sub = ap.add_subparsers(dest="command", required=True)

    sub.add_parser("status", help="查看本地安装状态").set_defaults(func=cmd_status)

    p_plan = sub.add_parser("plan", help="查询远端版本与资源清单")
    p_plan.add_argument("-v", "--verbose", action="store_true")
    p_plan.set_defaults(func=cmd_plan)

    p_install = sub.add_parser("install", help="下载并安装客户端（可选资源热更）")
    p_install.add_argument("--force", action="store_true")
    p_install.add_argument("--with-resources", action="store_true", help="安装后顺带预下载资源包")
    p_install.add_argument("--client-only", action="store_true", help="（默认行为，保留兼容）")
    p_install.add_argument("--kinds", default="")
    p_install.set_defaults(func=cmd_install)

    p_res = sub.add_parser("resources", help="下载/校验 YooAsset 资源包")
    p_res.add_argument("--kinds", default="")
    p_res.add_argument("--dry-run", action="store_true")
    p_res.set_defaults(func=cmd_resources)

    p_repair = sub.add_parser("repair", help="按 hash.json 校验并修复客户端文件")
    p_repair.add_argument("--native-build-id", type=int, default=0)
    p_repair.add_argument("--sync-outer-status", type=int, default=2)
    p_repair.add_argument("--client-version", default="1.0.2")
    p_repair.set_defaults(func=cmd_repair)

    p_launch = sub.add_parser("launch", help="通过 Proton/Wine 启动游戏")
    p_launch.add_argument("--proton", default=None)
    p_launch.add_argument("--use-proton", action="store_true", default=True)
    p_launch.add_argument("--no-proton", dest="use_proton", action="store_false")
    p_launch.add_argument("--prefix", default=None)
    p_launch.add_argument("--force-d3d11", action="store_true")
    p_launch.add_argument("--dry-run", action="store_true")
    p_launch.add_argument("--set-env", action="append", help="额外环境变量 K=V")
    p_launch.add_argument("passthrough", nargs="*", help="透传给游戏的参数")
    p_launch.set_defaults(func=cmd_launch)

    p_sign = sub.add_parser("sign", help="调试：打印签名头")
    p_sign.add_argument("--method", default="POST")
    p_sign.add_argument("--path", default="/launcher/app")
    p_sign.set_defaults(func=cmd_sign)

    p_unb = sub.add_parser("unbundle", help="解析或恢复 FairGuard UnityFS bundle")
    p_unb.add_argument("bundle", help="YooAsset __data 文件路径")
    p_unb.add_argument("--keystream", default="", help="已验证的完整首块 XOR 密钥流（hex）")
    p_unb.add_argument("--snapshot", default="", help="FairGuard 内存快照（需同名 .json 配置）；输出标准 UnityFS")
    p_unb.add_argument("-o", "--output", default="")
    p_unb.set_defaults(func=cmd_unbundle)

    p_carve = sub.add_parser("carve", help="从 CAB 数据流切割 HybridCLR DLL")
    p_carve.add_argument("stream", help="bundle 解出的数据流文件")
    p_carve.add_argument("-o", "--output", default="")
    p_carve.set_defaults(func=cmd_carve)

    p_dm = sub.add_parser("dump-meta", help="从运行中的游戏 dump 解密后的 IL2CPP 元数据")
    p_dm.add_argument("--pid", type=int, default=0)
    p_dm.add_argument("-o", "--output", default="global-metadata.dec.dat")
    p_dm.set_defaults(func=cmd_dump_meta)
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\n已中断", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
