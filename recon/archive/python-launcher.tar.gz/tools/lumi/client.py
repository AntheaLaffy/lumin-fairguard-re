"""把 API + 下载 + 解包 + 状态写盘串起来：等价于 Lumin.Launcher 的任务状态机。"""

from __future__ import annotations

import json
import os
import shutil
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from . import download as dl
from .api import LuminApi
from .store import (
    TYPE_TO_KEY,
    TYPE_TO_VERSION,
    AppInfo,
    GameLayout,
    LauncherConfig,
    ResourceVersion,
)

KINDS = ("Dll", "Assets", "ClientStatic", "RawFile")


@dataclass
class Plan:
    client_version: str = ""
    client_url: str = ""
    client_size: int = 0
    app_env: str = "Prod"
    resources: dict = field(default_factory=dict)  # kind -> [ {url,size,hash,tag} ]
    resource_versions: dict = field(default_factory=dict)  # kind -> int
    server_url: str = ""
    raw: dict = field(default_factory=dict)


def _join_cdn(cdn: str, url: str) -> str:
    if not url or url.lower().startswith(("http://", "https://")):
        return url
    return f"{cdn.rstrip('/')}/{url.lstrip('/')}"


class LumiClient:
    def __init__(self, config: LauncherConfig, layout: GameLayout, api: LuminApi, quiet: bool = False):
        self.config = config
        self.layout = layout
        self.api = api
        self.quiet = quiet

    # --- 计划 -----------------------------------------------------------
    def fetch_plan(self, installed: AppInfo | None = None) -> Plan:
        extra = {}
        if installed and installed.client_version:
            extra = {"env": installed.env, "client_version": installed.client_version}
        app = self.api.launcher_app(**extra)
        plan = Plan(
            client_version=app.get("client_version", ""),
            client_url=app.get("download_url", ""),
            client_size=int(app.get("zip_size") or 0),
            app_env=app.get("env") or self.config.extra.get("env", "Prod"),
            raw=app,
        )
        update = app.get("update") or {}
        if installed and update.get("client_version") and update.get("client_version") != installed.client_version:
            plan.client_version = update["client_version"]
            plan.client_url = update.get("download_url", "")
            plan.client_size = int(update.get("zip_size") or 0)
            plan.raw["_update"] = True

        build_id = int((app.get("build_id") or app.get("game_build_id") or 0))
        cfg = self.api.remote_config(
            build_id=build_id,
            client_version=plan.client_version,
            env=plan.app_env,
            channel=self.api.channel,
            target_platform="Win64",
            assets_version=0,
            client_static_version=0,
            dll_version=0,
            raw_file_version=0,
        )
        plan.server_url = cfg.get("server_url", "")
        for kind, key in (
            ("Assets", "assets"),
            ("ClientStatic", "client_static"),
            ("Dll", "dll"),
            ("RawFile", "raw_file"),
        ):
            block = cfg.get(key) or {}
            normal = block.get("normal") or {}
            cdn = block.get("cdn") or ""
            items = []
            for entry in (normal.get("full") or []) + (normal.get("diff") or []):
                items.append(
                    {
                        "url": _join_cdn(cdn, entry.get("url", "")),
                        "size": int(entry.get("size") or 0),
                        "hash": entry.get("hash") or "",
                        "tag": entry.get("tag") or "",
                    }
                )
            plan.resources[kind] = items
            plan.resource_versions[kind] = int(normal.get("version") or 0)
        return plan

    # --- 状态 -----------------------------------------------------------
    def status(self) -> dict:
        info = self.layout.read_app_info()
        ver = self.layout.read_resource_version()
        cached = None
        for candidate in sorted(self.layout.download_dir.glob("Download-*.zip")):
            cached = {"path": str(candidate), "size": candidate.stat().st_size}
        return {
            "game_path": str(self.layout.root),
            "installed": info is not None,
            "client_version": info.client_version if info else "",
            "env": info.env if info else "",
            "build_id": info.build_id if info else "",
            "resource_version": (ver.version_key if ver.has_version else "未预下载（游戏会自己拉）"),
            "cached_client_zip": cached,
            "exe": str(self.layout.exe),
            "exe_present": self.layout.exe.exists(),
        }

    # --- 客户端下载 / 安装 ----------------------------------------------
    def install_client(self, plan: Plan, force: bool = False) -> None:
        if not plan.client_url:
            raise dl.DownloadError("/launcher/app 未返回 download_url（可能渠道/环境不匹配）")
        target = self.layout.client_zip(plan.client_version)
        if self.layout.is_installed() and not force:
            info = self.layout.read_app_info()
            if info and info.client_version == plan.client_version:
                print(f"客户端已是 {plan.client_version}，跳过下载")
                return
        if dl.verify_zip(target, plan.client_size):
            print(f"复用已下载的完整包：{target}")
        else:
            print(f"下载客户端 {plan.client_version} -> {target} ({plan.client_size/1024/1024:.0f} MiB)")
            dl.download(
                plan.client_url,
                target,
                expected_size=plan.client_size,
                speed_limit_mb=self.config.speed_limit,
                quiet=self.quiet,
            )
        print("解包到 Bin/ ...")
        self.layout.install_dir.mkdir(parents=True, exist_ok=True)
        _extract_zip(target, self.layout.install_dir)
        self._patch_app_config(plan)
        self.layout.clean_download_cache()
        info = self.layout.read_app_info()
        print(f"安装完成：client_version={info.client_version if info else '?'} build_id={info.build_id if info else '?'}")

    def _patch_app_config(self, plan: Plan) -> None:
        """对齐 InstallingGameState：安装后把 cps 覆盖进 app_config.json。"""
        path = self.layout.app_config_path
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception:
            return
        if self.api.cps:
            data["cps"] = self.api.cps
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    # --- 资源热更 -------------------------------------------------------
    def install_resources(self, plan: Plan, kinds=KINDS, dry_run: bool = False) -> ResourceVersion:
        version = self.layout.read_resource_version()
        if not version.has_version:
            version = ResourceVersion(env=plan.app_env)
        for kind in kinds:
            items = plan.resources.get(kind) or []
            if not items:
                print(f"[{kind}] 无资源包")
                continue
            pending = [i for i in items if not self.layout.is_extracted(kind, i)]
            total = sum(i["size"] for i in pending)
            print(f"[{kind}] {len(items)} 个包，待下 {len(pending)} 个 / {total/1024/1024:.0f} MiB")
            if dry_run:
                for item in pending:
                    print(f"    {item['tag']:<8} {item['size']/1024/1024:9.1f} MiB  {item['url']}")
                continue
            for index, item in enumerate(pending, 1):
                zip_path = self.layout.zip_path(kind, item)
                if not dl.verify_zip(zip_path, item["size"]):
                    print(f"  ({index}/{len(pending)}) 下载 {item['tag']} {item['hash'][:6]}")
                    dl.download(
                        item["url"],
                        zip_path,
                        expected_size=item["size"],
                        speed_limit_mb=self.config.speed_limit,
                        quiet=self.quiet,
                    )
                if not dl.verify_zip(zip_path, item["size"]):
                    raise dl.DownloadError(f"资源包校验失败，已丢弃：{zip_path}")
                target = self.layout.res_install_dir(kind)
                target.mkdir(parents=True, exist_ok=True)
                _extract_zip(zip_path, target)
                marker = self.layout.marker_path(kind, item)
                marker.parent.mkdir(parents=True, exist_ok=True)
                marker.write_text("")
                zip_path.unlink(missing_ok=True)
            setattr(
                version,
                {"Assets": "assets", "ClientStatic": "client_static", "Dll": "dll", "RawFile": "raw_file"}[kind],
                str(plan.resource_versions.get(kind, "")),
            )
        if not dry_run:
            version.env = plan.app_env or version.env
            self.layout.write_resource_version(version)
            print(f"资源版本写入 {self.layout.version_file}: {version.version_key}")
        return version

    # --- 修复 -----------------------------------------------------------
    def repair(self, native_build_id: int, sync_outer_status: int = 2) -> None:
        base = (
            "https://lm-package.zhuziplay.com"
            if sync_outer_status == 2
            else "https://lm-package-qt.zhuziplay.com"
        )
        table_url = f"{base}/Win64/{native_build_id}/hash.json"
        files_url = f"{base}/Win64/{native_build_id}/files/"
        print(f"修复清单：{table_url}")
        table = dl.fetch_json(table_url)
        bad = 0
        import hashlib

        for index, entry in enumerate(table, 1):
            rel = entry["path"]
            local = self.layout.install_dir / rel
            if local.exists():
                digest = hashlib.md5(local.read_bytes()).hexdigest()
                if digest == entry["md5"]:
                    continue
            url = files_url + rel
            print(f"  ({index}/{len(table)}) 修复 {rel}")
            local.parent.mkdir(parents=True, exist_ok=True)
            dl.download(url, local, quiet=True)
            bad += 1
        print(f"修复完成，重下 {bad} 个文件")


def _extract_zip(zip_path: Path, target: Path) -> None:
    with zipfile.ZipFile(zip_path) as zf:
        for member in zf.infolist():
            name = member.filename
            if name.startswith("__MACOSX") or name.endswith("/.DS_Store") or name == ".DS_Store":
                continue
            zf.extract(member, target)
