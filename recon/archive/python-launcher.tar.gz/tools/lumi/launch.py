"""在 Linux 上启动 Unity IL2CPP 客户端（Proton 或系统 Wine）。

游戏本体没有 Linux 版：Lumin_Data/il2cpp_data 只带 Win64 profile，
必须走 Proton/Proton-GE 的 Wine + DXVK/VKD3D 路线。

启动参数对齐 PlayingGameState：
    Lumin.exe -launcher=lm -cps=<cps>
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

DEFAULT_PROTON_CANDIDATES = [
    "~/.steam/root/steamapps/common/Proton - Experimental",
    "~/.steam/steam/steamapps/common/Proton - Experimental",
    "~/.local/share/Steam/steamapps/common/Proton - Experimental",
    "~/.steam/root/steamapps/common/Proton 9.0",
    "~/.local/share/Steam/steamapps/common/GE-Proton",
    "~/.steam/root/compatibilitytools.d/GE-Proton",
]


def find_proton(explicit: str | None = None) -> Path | None:
    if explicit:
        path = Path(explicit).expanduser()
        return path if (path / "proton").exists() else None
    for candidate in DEFAULT_PROTON_CANDIDATES:
        path = Path(candidate).expanduser()
        if (path / "proton").exists():
            return path
    compat = Path("~/.steam/root/compatibilitytools.d").expanduser()
    if compat.exists():
        for entry in sorted(compat.iterdir()):
            if (entry / "proton").exists():
                return entry
    return None


def build_env(prefix: Path, steam_root: Path, extra: dict[str, str] | None = None) -> dict[str, str]:
    env = dict(os.environ)
    env.update(
        {
            "STEAM_COMPAT_DATA_PATH": str(prefix),
            "STEAM_COMPAT_CLIENT_INSTALL_PATH": str(steam_root),
            "WINEDLLOVERRIDES": env.get(
                "WINEDLLOVERRIDES", "mscoree=d;mshtml=d"
            ),
            "WINE_LARGE_ADDRESS_AWARE": "1",
            "DXVK_HUD": env.get("DXVK_HUD", ""),
            "PROTON_ENABLE_NVAPI": env.get("PROTON_ENABLE_NVAPI", "1"),
            "PROTON_USE_WINED3D": env.get("PROTON_USE_WINED3D", "0"),
        }
    )
    if extra:
        env.update(extra)
    return env


def launch(
    layout,
    proton_dir: Path | None,
    prefix: Path,
    cps: str = "",
    force_d3d11: bool = False,
    extra_args: list[str] | None = None,
    dry_run: bool = False,
    env_extra: dict[str, str] | None = None,
) -> int:
    exe = layout.exe
    if not exe.exists():
        raise SystemExit(f"找不到客户端：{exe}（先跑 install）")
    args = [str(exe), "-launcher=lm", f"-cps={cps}"]
    if force_d3d11:
        args.append("-force-d3d11")
    if extra_args:
        args.extend(extra_args)

    steam_root = Path("~/.steam/root").expanduser()
    if not steam_root.exists():
        steam_root = Path("~/.local/share/Steam").expanduser()

    if proton_dir:
        cmd = [str(Path(proton_dir) / "proton"), "run"] + args
        env = build_env(prefix, steam_root, env_extra)
    else:
        wine = shutil.which("wine")
        if not wine:
            raise SystemExit("既没有 Proton 也没有 wine，无法启动")
        cmd = [wine] + args
        env = dict(os.environ)
        env.setdefault("WINEPREFIX", str(prefix))
        if env_extra:
            env.update(env_extra)

    print("运行：", " ".join(cmd), file=sys.stderr)
    if dry_run:
        return 0
    return subprocess.call(cmd, cwd=str(layout.install_dir), env=env)
