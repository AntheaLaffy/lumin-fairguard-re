"""游戏目录布局 / 本地状态文件，对齐 PathUtilities 与 ResourceZipUtilities。"""

from __future__ import annotations

import json
import os
import shutil
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from . import localcrypto

RESOURCE_TYPES = ("Dll", "Assets", "ClientStatic", "RawFile")
TYPE_TO_KEY = {
    "Assets": "assets_zip",
    "ClientStatic": "client_static_zip",
    "Dll": "dll_zip",
    "RawFile": "raw_file_zip",
}
TYPE_TO_VERSION = {
    "Assets": "assets_version",
    "ClientStatic": "client_static_version",
    "Dll": "dll_version",
    "RawFile": "raw_file_version",
}


@dataclass
class AppInfo:
    """Bin/Lumin_Data/StreamingAssets/app_info 的结构。"""

    build_id: str = ""
    region: str = "CN"
    env: str = "Prod"
    channel: str = "bilibili"
    client_version: str = ""
    uwa: str = "0"
    config_url: str = "https://lmapi.zhuziplay.com"
    feedback_url: str = ""
    cps: str = ""

    @classmethod
    def parse(cls, text: str) -> "AppInfo":
        info = cls()
        for chunk in text.replace("\r", "").split(","):
            if "=" not in chunk:
                continue
            key, _, value = chunk.partition("=")
            key, value = key.strip(), value.strip()
            attr = {"build_id": "build_id", "UWA": "uwa"}.get(key, key)
            if hasattr(info, attr):
                setattr(info, attr, value)
        return info

    def serialize(self) -> str:
        pairs = [
            ("region", self.region),
            ("env", self.env),
            ("client_version", self.client_version),
            ("config_url", self.config_url),
            ("feedback_url", self.feedback_url),
            ("channel", self.channel),
            ("cps", self.cps),
            ("build_id", self.build_id),
            ("UWA", self.uwa),
        ]
        return ",".join(f"{k}={v}" for k, v in pairs if v)


@dataclass
class ResourceVersion:
    """Bin/Lumin_Data/res/version/version.txt。"""

    env: str = ""
    assets: str = ""
    client_static: str = ""
    dll: str = ""
    raw_file: str = ""

    @property
    def has_version(self) -> bool:
        return all([self.assets, self.client_static, self.dll, self.raw_file])

    @property
    def version_key(self) -> str:
        return f"a{self.assets}_cs{self.client_static}_d{self.dll}_r{self.raw_file}"

    @classmethod
    def parse(cls, text: str) -> "ResourceVersion":
        ver = cls()
        for line in text.splitlines():
            key, _, value = line.partition("=")
            if not _:
                continue
            mapping = {
                "AppEnv": "env",
                "AssetsVersion": "assets",
                "ClientStaticVersion": "client_static",
                "DllVersion": "dll",
                "RawFileVersion": "raw_file",
            }
            attr = mapping.get(key.strip())
            if attr:
                setattr(ver, attr, value.strip())
        return ver

    def serialize(self) -> str:
        return (
            f"AppEnv={self.env}\n"
            f"AssetsVersion={self.assets}\n"
            f"ClientStaticVersion={self.client_static}\n"
            f"RawFileVersion={self.raw_file}\n"
            f"DllVersion={self.dll}"
        )


@dataclass
class LauncherConfig:
    """对应 LauncherSettings + install_path。"""

    game_path: str = ""
    language: str = "zh-cn"
    close_action: int = 1
    speed_limit: int = 0
    extract_while_downloading: bool = True
    max_pending_extractions: int = 2
    device_id: str = ""
    cps: str = ""
    extra: dict = field(default_factory=dict)

    def save(self, data_dir: Path) -> None:
        data_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "game_path": self.game_path,
            "language": self.language,
            "close_action": self.close_action,
            "speed_limit": self.speed_limit,
            "extract_while_downloading": self.extract_while_downloading,
            "max_pending_extractions": self.max_pending_extractions,
            "device_id": self.device_id,
            "cps": self.cps,
            **self.extra,
        }
        (data_dir / "config.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False))
        # 兼容原生启动器：install_path 是明文路径，config.lmc 是 AES 加密的 JSON
        (data_dir / "install_path").write_text(self.game_path)
        native = {
            "language": self.language,
            "auto_start": False,
            "close_action": self.close_action,
            "speed_limit": self.speed_limit,
            "extract_while_downloading": self.extract_while_downloading,
            "max_pending_extractions": self.max_pending_extractions,
            "game_path": self.game_path,
        }
        (data_dir / "config.lmc").write_bytes(localcrypto.encrypt_blob(json.dumps(native).encode()))

    @classmethod
    def load(cls, data_dir: Path) -> "LauncherConfig":
        cfg = cls()
        plain = data_dir / "config.json"
        if plain.exists():
            data = json.loads(plain.read_text())
            for key, value in data.items():
                if hasattr(cfg, key):
                    setattr(cfg, key, value)
                else:
                    cfg.extra[key] = value
            return cfg
        lmc = data_dir / "config.lmc"
        if lmc.exists():
            try:
                data = json.loads(localcrypto.decrypt_blob(lmc.read_bytes()))
            except Exception:
                data = {}
            cfg.game_path = data.get("game_path", "")
            cfg.language = data.get("language", cfg.language)
            cfg.speed_limit = data.get("speed_limit", 0)
            cfg.extract_while_downloading = data.get("extract_while_downloading", True)
            cfg.max_pending_extractions = data.get("max_pending_extractions", 2)
        ip = data_dir / "install_path"
        if not cfg.game_path and ip.exists():
            cfg.game_path = ip.read_text().strip()
        return cfg

    @classmethod
    def ensure_device_id(cls, data_dir: Path) -> "LauncherConfig":
        cfg = cls.load(data_dir)
        if not cfg.device_id:
            # 原生实现取 MachineGuid；Linux 上首次生成后持久化即可
            cfg.device_id = str(uuid.uuid4())
            cfg.save(data_dir)
        return cfg


class GameLayout:
    """和 PathUtilities / ResourceZipUtilities 完全一致的路径推导。"""

    def __init__(self, game_path: str | Path):
        self.root = Path(game_path).expanduser()

    @property
    def install_dir(self) -> Path:
        return self.root / "Bin"

    @property
    def download_dir(self) -> Path:
        return self.root / "DownloadCache"

    def client_zip(self, version: str) -> Path:
        return self.download_dir / f"Download-{version}.zip"

    @property
    def exe(self) -> Path:
        return self.install_dir / "Lumin.exe"

    @property
    def app_info_path(self) -> Path:
        return self.install_dir / "Lumin_Data" / "StreamingAssets" / "app_info"

    @property
    def app_config_path(self) -> Path:
        return self.install_dir / "Lumin_Data" / "StreamingAssets" / "app_config.json"

    @property
    def version_file(self) -> Path:
        return self.install_dir / "Lumin_Data" / "res" / "version" / "version.txt"

    def res_download_dir(self, kind: str) -> Path:
        return self.install_dir / "Lumin_Data" / "res" / "downloads" / kind

    def res_marker_dir(self, kind: str) -> Path:
        return self.install_dir / "Lumin_Data" / "res" / "zipmarkers" / kind

    def res_install_dir(self, kind: str) -> Path:
        return self.install_dir / "Lumin_Data" / "yoo" / kind / "BundleFiles"

    def predownload_dir(self, version_key: str, kind: str) -> Path:
        return (
            self.install_dir
            / "Lumin_Data"
            / "res"
            / "pre-download"
            / version_key
            / "downloads"
            / kind
        )

    # --- 读取 ------------------------------------------------------------
    def read_app_info(self) -> AppInfo | None:
        path = self.app_info_path
        if not self.exe.exists() or not path.exists():
            return None
        try:
            info = AppInfo.parse(localcrypto.decrypt_text(path.read_text().strip()))
        except Exception:
            return None
        return info if info.client_version else None

    def read_resource_version(self) -> ResourceVersion:
        return ResourceVersion.parse(localcrypto.read_aot(str(self.version_file)))

    def write_resource_version(self, version: ResourceVersion) -> None:
        localcrypto.write_aot(str(self.version_file), version.serialize())

    def write_app_info(self, info: AppInfo) -> None:
        self.app_info_path.parent.mkdir(parents=True, exist_ok=True)
        self.app_info_path.write_text(localcrypto.encrypt_text(info.serialize()))

    # --- 状态判定 ---------------------------------------------------------
    def is_installed(self) -> bool:
        return self.read_app_info() is not None

    def marker_path(self, kind: str, resource: dict) -> Path:
        name = f"{resource['hash']}_{resource['size']}"
        return self.res_marker_dir(kind) / f"{name}.marker"

    def zip_path(self, kind: str, resource: dict) -> Path:
        name = f"{resource['hash']}_{resource['size']}"
        return self.res_download_dir(kind) / f"{name}.zip"

    def is_extracted(self, kind: str, resource: dict) -> bool:
        target = self.res_install_dir(kind)
        if not target.exists():
            return False
        if not any(target.iterdir()):
            return False
        return self.marker_path(kind, resource).exists()

    def clean_download_cache(self) -> None:
        if self.download_dir.exists():
            shutil.rmtree(self.download_dir, ignore_errors=True)
