"""lumi —— 绿梦：时空之声（Lumin / zhuziplay）的 Linux 原生启动器。

替代 Windows 侧 Lumin.Launcher（.NET WPF + WebView2）：
版本判定、客户端包下载、YooAsset 资源热更、hash.json 修复、Proton 启动。
"""

__version__ = "1.0.0"
