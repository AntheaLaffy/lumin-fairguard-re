# lumi —— 绿梦：时空之声 Linux 原生启动器

Windows 官方启动器是 `Lumin.Launcher`（.NET 8 WPF + WebView2），WebView2 里跑
`https://lvmeng-starter.zhuziplay.com` 的 SPA，SPA 通过 `BridgeLinker` COM 宿主对象调用本地能力，
所有业务数据来自 `https://lmapi.zhuziplay.com`。

`lumi` 把这套逻辑用 Python 重写，去掉 WPF/WebView2/.NET 依赖，在 Linux 上完成同样的
**版本判定 → 客户端包下载 → 解包 → 资源热更 → hash.json 修复 → 启动** 流程，
最后交给 Proton（或系统 Wine）跑 Unity IL2CPP 的 Windows 客户端。

## 安装依赖

```bash
python3 -m pip install --user cryptography     # AES-GCM 签名 + 本地状态文件加解密
```

## 用法

```bash
# 全局参数（写在子命令之前）
export LUMI_GAME_PATH=~/Games/lvmeng        # 游戏根目录，客户端会装到 $LUMI_GAME_PATH/Bin
python3 -m lumi status
python3 -m lumi plan -v                     # 远端版本 + 资源包清单
python3 -m lumi install --client-only       # 只装客户端（约 606 MiB）
python3 -m lumi resources --dry-run         # 看资源热更要下多少
python3 -m lumi resources --kinds Dll,ClientStatic
python3 -m lumi repair                      # 按 hash.json 补文件
python3 -m lumi launch --force-d3d11        # 通过 Proton 启动
```

`launch` 会探测 `Proton - Experimental` / `GE-Proton`；也可 `--proton /path/to/Proton`
或 `--no-proton` 走系统 wine。启动参数与官方一致：`Lumin.exe -launcher=lm -cps=<cps>`。

## 目录约定（与服务端/官方启动器一致）

```
$LUMI_GAME_PATH/
├── Bin/                                  # 客户端解包目录（= PathUtilities.InstallDir）
│   ├── Lumin.exe
│   ├── Lumin_Data/
│   │   ├── StreamingAssets/app_info      # base64(AES-192-CBC) 版本信息
│   │   ├── StreamingAssets/app_config.json
│   │   ├── res/version/version.txt       # "ENC:" + base64(AES-256-CBC)
│   │   ├── res/downloads/<Type>/         # 资源 zip 中转
│   │   ├── res/zipmarkers/<Type>/        # <hash>_<size>.marker
│   │   └── yoo/<Type>/BundleFiles/       # YooAsset 解包目标
└── DownloadCache/Download-<ver>.zip      # 客户端整包
```

本地启动器状态放在 `--data-dir`（默认 `~/.local/share/lumi`）：
`config.json`、`config.lmc`（AES-192-CBC，供官方启动器复用）、`install_path`。

## 模块

| 文件 | 作用 |
| --- | --- |
| `api.py` | 签名 API 客户端（HMAC-SHA256 + AES-GCM 包装） |
| `localcrypto.py` | `config.lmc` / `cache.lmc` / `version.txt` 的两种对称加密 |
| `store.py` | 目录布局、`app_info` 与 `version.txt` 读写、marker 判定 |
| `download.py` | Range 续传、限速、zip CRC 校验 |
| `client.py` | 版本计划、客户端安装、资源热更、修复 |
| `launch.py` | Proton/Wine 启动 |

## 已知限制

- 资源热更合计约 24 GiB（Assets 18.6 GiB + RawFile 5.4 GiB），默认只下 Dll/ClientStatic 也能启动到登录界面。
- 客户端是 Unity IL2CPP Win64 + FairGuard 加固，只能跑在 Proton/Wine 下，详见仓库根 `REPORT.md`。
- `device_id` 官方取 Windows `MachineGuid`；这里首次运行随机生成并持久化，服务端只把它当设备标识，不影响取包。
