"""启动器用到的两种本地加密，逐字节对齐 Lumin.Launcher.dll。"""

from __future__ import annotations

import base64
import hashlib
import os

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7

# Lumin.Launcher.Utilities.AesEncryption.Key（base64 解出 24 字节 -> AES-192-CBC）
AES_CONFIG_KEY = base64.b64decode("yv82l+V4Q7XuxDX0UOaWye4AVLPUZ5XM")
# ACT.AotCrypto 的派生口令
AOT_PASSPHRASE = "Lumin_Key_v1"
AOT_PREFIX = "ENC:"
_AOT_KEY = hashlib.sha256(AOT_PASSPHRASE.encode()).digest()


def _cbc_encrypt(key: bytes, iv: bytes, data: bytes) -> bytes:
    padder = PKCS7(128).padder()
    padded = padder.update(data) + padder.finalize()
    encryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
    return encryptor.update(padded) + encryptor.finalize()


def _cbc_decrypt(key: bytes, iv: bytes, data: bytes) -> bytes:
    decryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    padded = decryptor.update(data) + decryptor.finalize()
    unpadder = PKCS7(128).unpadder()
    return unpadder.update(padded) + unpadder.finalize()


def encrypt_blob(plain: bytes) -> bytes:
    """config.lmc / cache.lmc：IV(16) || AES-192-CBC(PKCS7)。"""
    iv = os.urandom(16)
    return iv + _cbc_encrypt(AES_CONFIG_KEY, iv, plain)


def decrypt_blob(data: bytes) -> bytes:
    return _cbc_decrypt(AES_CONFIG_KEY, data[:16], data[16:])


def encrypt_text(text: str) -> str:
    return base64.b64encode(encrypt_blob(text.encode())).decode()


def decrypt_text(token: str) -> str:
    return decrypt_blob(base64.b64decode(token.strip())).decode("utf-8", "replace")


def write_aot(path: str, text: str) -> None:
    """version.txt / res 版本文件：'ENC:' + base64(IV || AES-256-CBC(sha256(passphrase)))。"""
    iv = os.urandom(16)
    payload = _cbc_encrypt(_AOT_KEY, iv, text.encode())
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(AOT_PREFIX + base64.b64encode(iv + payload).decode())


def read_aot(path: str) -> str:
    if not os.path.exists(path):
        return ""
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        text = fh.read()
    if not text:
        return ""
    if not text.startswith(AOT_PREFIX):
        return text  # 明文兼容
    raw = base64.b64decode(text[len(AOT_PREFIX) :])
    if len(raw) < 17:
        return ""
    return _cbc_decrypt(_AOT_KEY, raw[:16], raw[16:]).decode("utf-8", "replace")
