#!/usr/bin/env python3
"""Remote ZIP inspector over HTTP range requests.

Lists entries of a remote zip (CD-based) and extracts selected members
without downloading the whole archive.
"""
from __future__ import annotations

import argparse
import io
import struct
import sys
import zipfile
import urllib.request

EOCD_SIG = b"PK\x05\x06"
ZIP64_LOCATOR_SIG = b"PK\x06\x07"
ZIP64_EOCD_SIG = b"PK\x06\x06"


class RangeReader(io.RawIOBase):
    def __init__(self, url: str, size: int, block: int = 1 << 16):
        self.url = url
        self.size = size
        self.block = block
        self.pos = 0
        self._buf = b""
        self._buf_start = 0

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return True

    def tell(self) -> int:
        return self.pos

    def seek(self, offset: int, whence: int = io.SEEK_SET) -> int:
        if whence == io.SEEK_SET:
            self.pos = offset
        elif whence == io.SEEK_CUR:
            self.pos += offset
        elif whence == io.SEEK_END:
            self.pos = self.size + offset
        return self.pos

    def _fetch(self, start: int, length: int) -> bytes:
        end = min(start + length - 1, self.size - 1)
        req = urllib.request.Request(self.url, headers={"Range": f"bytes={start}-{end}"})
        with urllib.request.urlopen(req, timeout=120) as resp:
            return resp.read()

    def readinto(self, b) -> int:  # type: ignore[override]
        want = len(b)
        if want == 0 or self.pos >= self.size:
            return 0
        if not (self._buf_start <= self.pos < self._buf_start + len(self._buf)):
            self._buf = self._fetch(self.pos, self.block)
            self._buf_start = self.pos
        start = self.pos - self._buf_start
        chunk = self._buf[start : start + want]
        b[: len(chunk)] = chunk
        self.pos += len(chunk)
        return len(chunk)


def open_remote_zip(url: str) -> zipfile.ZipFile:
    req = urllib.request.Request(url, method="HEAD")
    with urllib.request.urlopen(req, timeout=60) as resp:
        size = int(resp.headers["Content-Length"])
    reader = RangeReader(url, size)
    return zipfile.ZipFile(io.BufferedReader(reader, buffer_size=1 << 16))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--grep", default=None)
    ap.add_argument("--extract", nargs="*", default=[])
    ap.add_argument("--out", default=".")
    args = ap.parse_args()

    zf = open_remote_zip(args.url)
    if args.list or args.grep or not args.extract:
        import re

        pat = re.compile(args.grep) if args.grep else None
        infos = zf.infolist()
        print(f"{len(infos)} entries")
        total = 0
        for info in infos:
            total += info.file_size
            if pat and not pat.search(info.filename):
                continue
            print(f"{info.file_size:>12}  {info.filename}")
        print(f"total uncompressed: {total/ (1024**3):.2f} GiB")
    for member in args.extract:
        data = zf.read(member)
        out = f"{args.out}/{member.split('/')[-1]}"
        with open(out, "wb") as fh:
            fh.write(data)
        print(f"extracted {member} -> {out} ({len(data)} bytes)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
