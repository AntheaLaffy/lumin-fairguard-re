#!/usr/bin/env python3
"""Lumin launcher API client (lvmeng / 绿梦：时空之声).

Reproduces the request signature scheme recovered from the starter SPA
(https://lvmeng-starter.zhuziplay.com/assets/index-*.js) plus the launcher
bridge contracts from Lumin.Launcher.dll.

Signature algorithm
-------------------
secret      = "57e5177a6752ef98e3a7c9b6c9f06e35"
headers     = x_app_id=1038, x_device_id, x_nonce=<32 alnum>, x_platform=Web,
              x_timestamp=<unix seconds>
payload     = pct(UPPER(method)) + pct(path) + "&"
              + for k in sorted(headers): f"{k}={v}&"
              + "key=" + secret
x_signature = base64( nonce12 || AESGCM(key=sha256(secret+"_aes"), nonce12, msg=hex(HMAC_SHA256(secret, payload))) )
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import os
import random
import string
import sys
import time
import urllib.parse
import urllib.request

API_BASE = "https://lmapi.zhuziplay.com"
SIGNATURE_SECRET = "57e5177a6752ef98e3a7c9b6c9f06e35"
SIGNATURE_PLATFORM = "Web"
SIGNATURE_APP_ID = "1038"
NONCE_CHARS = string.ascii_letters + string.digits


def percent_encode(value: str) -> str:
    out = urllib.parse.quote(value, safe="-_.!~*'()")
    return "".join(
        f"%{ord(ch):02X}" if ch in "!'()*" else ch for ch in out
    )


def create_nonce(length: int = 32) -> str:
    return "".join(random.SystemRandom().choice(NONCE_CHARS) for _ in range(length))


def _aes_gcm_encrypt(key: bytes, nonce: bytes, plaintext: bytes) -> bytes:
    """AES-256-GCM; uses cryptography if present, else pycryptodome."""
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        return AESGCM(key).encrypt(nonce, plaintext, None)
    except ImportError:
        pass
    try:
        from Crypto.Cipher import AES

        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        ct, tag = cipher.encrypt_and_digest(plaintext)
        return ct + tag
    except ImportError as exc:  # pragma: no cover
        raise SystemExit("need `cryptography` or `pycryptodome`") from exc


def build_payload(headers: dict[str, str], method: str, path: str) -> str:
    body = f"{percent_encode(method.upper())}{percent_encode(path)}&"
    for key in sorted(headers):
        body += f"{key}={headers[key] if headers[key] is not None else ''}&"
    return f"{body}key={SIGNATURE_SECRET}"


def signature_headers(method: str, path: str, device_id: str) -> dict[str, str]:
    headers = {
        "x_app_id": SIGNATURE_APP_ID,
        "x_device_id": device_id,
        "x_nonce": create_nonce(),
        "x_platform": SIGNATURE_PLATFORM,
        "x_timestamp": str(int(time.time())),
    }
    digest = hmac.new(
        SIGNATURE_SECRET.encode(),
        build_payload(headers, method, path).encode(),
        hashlib.sha256,
    ).hexdigest()
    key = hashlib.sha256(f"{SIGNATURE_SECRET}_aes".encode()).digest()
    nonce = os.urandom(12)
    sealed = _aes_gcm_encrypt(key, nonce, digest.encode())
    headers["x_signature"] = base64.b64encode(nonce + sealed).decode()
    return headers


class LuminClient:
    def __init__(
        self,
        device_id: str,
        region: str = "CN",
        launcher_env: str = "Prod",
        channel: str = "bilibili",
        cps: str = "",
        token: str | None = None,
        base_url: str = API_BASE,
        timeout: int = 30,
    ) -> None:
        self.device_id = device_id
        self.region = region
        self.launcher_env = launcher_env
        self.channel = channel
        self.cps = cps
        self.token = token
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def post(self, path: str, payload: dict | None = None) -> dict:
        body = dict(payload or {})
        body.setdefault("region", self.region)
        body.setdefault("launcher_env", self.launcher_env)
        body.setdefault("channel", self.channel)
        body.setdefault("device_id", self.device_id)
        raw = json.dumps(body).encode()
        headers = {
            "Content-Type": "application/json;charset=UTF-8",
            "Accept": "application/json, text/plain, */*",
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
            ),
            "Origin": "https://lvmeng-starter.zhuziplay.com",
            "Referer": "https://lvmeng-starter.zhuziplay.com/",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        headers.update(signature_headers("POST", path, self.device_id))
        req = urllib.request.Request(
            self.base_url + path, data=raw, headers=headers, method="POST"
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            return json.loads(resp.read().decode())

    # --- endpoint wrappers -------------------------------------------------
    def launcher_app(self, **extra) -> dict:
        return self.post("/launcher/app", extra)

    def launcher_update(self, client_version: str) -> dict:
        return self.post("/launcher/update", {"client_version": client_version})

    def native_build_id(self, **extra) -> dict:
        return self.post("/native/buildId", extra)

    def remote_config(self, **extra) -> dict:
        return self.post("/remote/config", extra)

    def announcement(self, **extra) -> dict:
        return self.post("/launcher/announcement", extra)

    def banner(self, **extra) -> dict:
        return self.post("/launcher/banner", extra)

    def shield(self, **extra) -> dict:
        return self.post("/launcher/shield", extra)


def main() -> int:
    ap = argparse.ArgumentParser(description="Lumin launcher API client")
    ap.add_argument("endpoint", help="launcher_app|launcher_update|native_build_id|remote_config|announcement|banner|shield|raw")
    ap.add_argument("--path", help="raw path for endpoint=raw")
    ap.add_argument("--device-id", default=os.environ.get("LUMIN_DEVICE_ID", ""))
    ap.add_argument("--channel", default="bilibili")
    ap.add_argument("--region", default="CN")
    ap.add_argument("--env", dest="launcher_env", default="Prod")
    ap.add_argument("--token", default=os.environ.get("LUMIN_TOKEN") or None)
    ap.add_argument("--client-version", default="")
    ap.add_argument("--data", default="{}", help="extra JSON body merged in")
    args = ap.parse_args()

    if not args.device_id:
        ap.error("--device-id or LUMIN_DEVICE_ID required")

    client = LuminClient(
        device_id=args.device_id,
        region=args.region,
        launcher_env=args.launcher_env,
        channel=args.channel,
        token=args.token,
    )
    extra = json.loads(args.data)
    if args.endpoint == "raw":
        out = client.post(args.path, extra)
    elif args.endpoint == "launcher_update":
        out = client.launcher_update(args.client_version or "1.0.2.3")
    else:
        out = getattr(client, args.endpoint)(**extra)
    json.dump(out, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
